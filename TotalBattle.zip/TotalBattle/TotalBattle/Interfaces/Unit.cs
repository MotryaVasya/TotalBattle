﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace TotalBattle.Interfaces
{
    class Unit : IUnit
    {
        public event Action<IUnit> onKill;


        #region fields
        private float _health;
        private float _maxHealth;
        private float _baseDamage;
        private IWeapon _weapon;
        private IArmor _armor;
        public bool _block;
        #endregion
        #region properties
        public float Health { get => _health; set => _health = value; }

        public float Damage
        {
            get
            {
                return _baseDamage;
            }
        }

        public IArmor Armor => _armor;

        public IWeapon Weapon => _weapon;

        public bool IsBlocks { get => _block; }
        #endregion
        #region constructors
        public Unit(float health, float damage, IWeapon weapon, IArmor armor)
        {
            _health = health;
            _baseDamage = damage;
            _weapon = weapon;
            _armor = armor;
            _maxHealth = health;
        }
        public Unit() : this(100, 5, Objects.WeaponArsenal.sword, Objects.ArmorArsenal.leather) { }
        #endregion

        public bool Attack(IUnit enemy)
        {
            if ((IsBlocks) || (enemy.IsBlocks)) return false;
            
            enemy.Health -= Damage;
            if (enemy.Health <= 0f)
            {
                onKill?.Invoke(enemy);
                return true;
            }
            else
            {
                enemy.Health -= RealDamage(enemy.Armor);
                return false;
            }
        }

        private float RealDamage(IArmor armor)
        {
            
        }

        public void Heal(float value)
        {
            if ((Health <= 0f) || (Health>=_maxHealth)) return;
            Health += value;
            if (Health > _maxHealth) Health = _maxHealth;
        }

        public void Block()
        {
            Random rnd = new Random();
            _block = rnd.Next(0, 100) <= 30;
        }
    }
}
