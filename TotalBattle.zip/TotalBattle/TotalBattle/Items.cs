﻿namespace TotalBattle
{
    enum Weapons
    {
        slashing, //режущий
        piercing, //колющий
        bludgeoning, //дробящий
    }

    enum Armors
    {
        light, //легкая броня
        medium, //средняя броня
        heavy, //тяжелая броня
    }
}
